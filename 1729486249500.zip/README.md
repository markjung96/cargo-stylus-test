# Stylus SingleCall

This contract features a single method `execute` which takes two args: a `target` address and `data` bytes. The `execute` function will pass the `data` to the `target`.

There is an example script showing how to use this contract in the `scripts` folder. See [`scripts/README.md`](scripts/README.md) for further details.
